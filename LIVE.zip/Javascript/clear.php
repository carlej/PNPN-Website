<?php 
$_SESSION['hold']="hold";
$_SESSION['temp']="temp";
$_SESSION['multsearch']=array('1');
$_SESSION['stype']=NULL;
$_SESSION['nest']="hold";
$_SESSION['nstype']=NULL;
?>


