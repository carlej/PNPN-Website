This font is not an official font, but is inspired by the characters on the coming attraction poster "Pirates of the Caribbean" and is not affiliated with The Walt Disney Company in any way.

All official material on Pirates of the Caribbean is copyright by Walt Disney Pictures. 

This is fan-produced material intended to promote interest in Pirates of the Caribbean. 

The materials are provided as FREEWARE for your enjoyment, and is not be used for any commercial or publication purpose.
Introduction
~~~~~~~~~~~~
Thank you for downloading Pieces of Eight Fonts TTF for Windows, I hope you enjoy using it. 

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP�

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:09/28/2006
Filename: Pieces of Eight Fonts.zip 
Title: Pieces of Eight
Category: Movie
Archive: Fonts

Other Themes are available.

Suggestions or comments sent to Steve Ferrera : supercarguy@hotmail.com
ENJOY!!!


RuFus


