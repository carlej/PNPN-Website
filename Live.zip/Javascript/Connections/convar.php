<?php
  // Define database connection constants
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASSWORD', 'Pinda4656');
  define('DB_NAME', 'PNPN-Website');
  define('CON_STRING', 'mysql:host=localhost;dname=root');

//  define('DB_NAME', 'KeyConnections');
//  define('DB_HOST', 'unknown');
//  define('DB_USER', 'generalcarle');
//  define('CON_STRING', 'mysql:host=unknown;dname=generalcarle');
?>
