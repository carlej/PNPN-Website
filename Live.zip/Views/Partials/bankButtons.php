<!doctype html>
<html>
<form method="post" id= "accountActions">
	<p>
		<input type = "submit" name= "button" value = "Transfer"?>
	</p>
</form>
</html>