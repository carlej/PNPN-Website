<!doctype html>
<html>
	<head>
		<?php include("Javascript/Connections/req.php"); 
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
			$username = $_SESSION['username'];
		}
		?>

		<title>Land Grants</title>
		<?php include("Views/Partials/header.php");?>
		
		<div class = "container-flow" id = "SwitchButtonsVol">
			<div class="d-none d-lg-block">
			<div class = "d-flex justify-content-center">
				<div class = "row" id ="ButtonsRow">
					<div class = "col" style="padding-right: 0.05em;">
						<a href="landgrant.php" class="PersonalButton3">Personal</a>
					</div>
					<div class = "col" style = "padding-left: 0.05em; padding-right: 0.05em">
						<a href="landsteward.php" class="LandPressed3">Steward</a>
					</div>
					<div class = "col" style="padding-left: 0.05em;">
						<a href="landvolunteer.php" class="LandVolunteer">Volunteer</a>
					</div>
				</div>
			</div>
			</div>
		</div>

		<!-- Code for the teller and personal buttons once the page is shrunk-->
		<div class = "container" id = "SwitchButtonsMenuVol">
			<div class="d-lg-none">
			<div class = "d-flex justify-content-center">
				<div class = "row">
					<div class = "col-lg">
						<a href="landgrant.php" class="PersonalButton2">Personal</a>
					</div>
					<div class = "col-lg">
						<a href="landsteward.php" class="LandPressed2">Steward</a>
					</div>
					<div class = "col-lg">
						<a href="landvolunteer.php" class="LandVolunteer2">Volunteer</a>
					</div>
				</div>
			</div>
			</div>
		</div>

		
	</head>
	<body>
		
	</body>

</html>