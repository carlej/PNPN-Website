<!doctype html>
<html>
	<head>
		<?php 
		//echo $_SERVER['HTTP_HOST'];
		//echo $_SERVER['PHP_SELF'];
		?><script type="text/javascript">window.location.href="bank.php"</script><?php?>

		
	</head>

</html>
